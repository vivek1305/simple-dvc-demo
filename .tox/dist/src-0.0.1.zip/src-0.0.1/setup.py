from setuptools import setup, find_packages

setup(
    name="src",
    version = "0.0.1",
    description = "This is wine Q package",
    author="vivek1305",
    packages=find_packages(),
    license="MIT"
)